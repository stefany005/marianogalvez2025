﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

class Venta
{
    public string Sucursal { get; set; }
    public string Gerente { get; set; }
    public string Vendedor { get; set; }
    public DateTime Fecha { get; set; }
    public int ProductoID { get; set; }
    public int CantidadVendida { get; set; }

    public Venta(string sucursal, string gerente, string vendedor, DateTime fecha, int productoID, int cantidadVendida)
    {
        Sucursal = sucursal;
        Gerente = gerente;
        Vendedor = vendedor;
        Fecha = fecha;
        ProductoID = productoID;
        CantidadVendida = cantidadVendida;
    }
}

class SupermercadoVentas
{
    static List<Venta> ventas = new List<Venta>();

    static void Main()
    {
        GenerarDatos();
        Console.WriteLine($"Se generaron {ventas.Count} registros de ventas.");
        Console.WriteLine("Presione ENTER para continuar...");
        Console.ReadLine();
        MostrarMenu();
    }

    static void MostrarMenu()
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("====================================");
            Console.WriteLine("       📊 MENÚ DE REPORTES         ");
            Console.WriteLine("====================================");
            Console.WriteLine("1. Reporte General de Ventas");
            Console.WriteLine("2. Reporte de Vendedores por Mes");
            Console.WriteLine("3. Salir");
            Console.Write("Seleccione una opción: ");

            string opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1":
                    MostrarVentasMensualesConVendedorDelMes();
                    break;
                case "2":
                    MostrarReporteVendedoresPorMes();
                    break;
                case "3":
                    Console.WriteLine("Saliendo...");
                    return;
                default:
                    Console.WriteLine("Opción inválida, presione ENTER para intentar de nuevo.");
                    Console.ReadLine();
                    break;
            }
        }
    }

    static void GenerarDatos()
    {
        string[] sucursales = { "Centro", "Norte", "Sur", "Este", "Oeste" };
        string[] gerentes = { "Juan Pérez", "María Gómez", "Carlos Ruiz", "Ana Torres", "Pedro Martínez" };
        Dictionary<string, string[]> vendedoresPorSucursal = new Dictionary<string, string[]> {
            { "Centro", new[] { "Luis Rojas", "Carmen Díaz" } },
            { "Norte", new[] { "José López", "Sofía Herrera" } },
            { "Sur", new[] { "Raúl Castro", "Ana Fernández" } },
            { "Este", new[] { "Pedro Sánchez", "Laura Torres" } },
            { "Oeste", new[] { "Miguel Ángel", "Elena Ruiz" } }
        };

        Random rand = new Random();
        DateTime fechaInicio = DateTime.Now.AddYears(-5);

        for (int i = 0; i < 60; i++) // 60 meses (5 años)
        {
            DateTime fecha = fechaInicio.AddMonths(i);
            foreach (var sucursal in sucursales)
            {
                string gerente = gerentes[Array.IndexOf(sucursales, sucursal)];
                string[] vendedores = vendedoresPorSucursal[sucursal];

                for (int productoID = 100; productoID < 110; productoID++)
                {
                    string vendedor = vendedores[rand.Next(vendedores.Length)];
                    int cantidadVendida = rand.Next(10, 500);

                    ventas.Add(new Venta(sucursal, gerente, vendedor, fecha, productoID, cantidadVendida));
                }
            }
        }
    }

    static void MostrarVentasMensualesConVendedorDelMes()
    {
        Console.Clear();
        Console.WriteLine("📌 Reporte General de Ventas");
        Console.WriteLine("--------------------------------------------------------------------------------------------");
        Console.WriteLine(" Fecha      | Sucursal   | Gerente         | Vendedor        | Producto | Cantidad Vendida |");
        Console.WriteLine("--------------------------------------------------------------------------------------------");

        foreach (var venta in ventas.OrderBy(v => v.Fecha))
        {
            Console.WriteLine($" {venta.Fecha:yyyy-MM-dd} | {venta.Sucursal,-10} | {venta.Gerente,-15} | {venta.Vendedor,-15} | {venta.ProductoID,-8} | {venta.CantidadVendida,10}       |");
        }

        Console.WriteLine("--------------------------------------------------------------------------------------------");
        Console.WriteLine("Reporte generado. Presione ENTER para volver al menú.");
        Console.ReadLine();
    }

    static void MostrarReporteVendedoresPorMes()
    {
        Console.Clear();
        Console.WriteLine("📌 Reporte de Vendedores del Mes");
        Console.WriteLine("----------------------------------");
        Console.WriteLine("----------------------------------");

        var ventasPorSucursalYMes = ventas
            .GroupBy(v => new { v.Fecha.Year, v.Fecha.Month, v.Sucursal })
            .OrderBy(g => g.Key.Year)
            .ThenBy(g => g.Key.Month)
            .ThenBy(g => g.Key.Sucursal);

        int añoActual = -1;
        foreach (var grupo in ventasPorSucursalYMes)
        {
            if (grupo.Key.Year != añoActual)
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("----------------------------------------------------------------------------------------------");
                Console.WriteLine(" Año  | Mes  | Sucursal   | Gerente          | Vendedor        |        Cantidad             |");
                Console.WriteLine("----------------------------------------------------------------------------------------------");
                Console.WriteLine("      |      |            |                  |                 |                             |");
                añoActual = grupo.Key.Year;
            }

            var vendedorDelMes = grupo
                .GroupBy(v => v.Vendedor)
                .Select(g => new { Vendedor = g.Key, TotalVentas = g.Sum(v => v.CantidadVendida) })
                .OrderByDescending(v => v.TotalVentas)
                .First();

            string gerente = grupo.First().Gerente;
            Console.WriteLine($" {grupo.Key.Year,-4} | {grupo.Key.Month,-4} | {grupo.Key.Sucursal,-10} | {gerente,-15}  | {vendedorDelMes.Vendedor,-15} |{vendedorDelMes.TotalVentas,10:N0} unidades vendidas |");
            Console.WriteLine("----------------------------------------------------------------------------------------------");
        }

        Console.WriteLine("Reporte generado. Presione ENTER para volver al menú.");
        Console.ReadLine();
    }
}
