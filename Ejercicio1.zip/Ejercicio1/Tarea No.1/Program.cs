﻿using System;

public class ManejoNota
{
    private int[] notas; // Arreglo de notas
    private int indice;  // Control de la posición actual
    private int longitud; // Tamaño máximo del arreglo

    public ManejoNota(int longitud)
    {
        this.longitud = longitud;
        this.notas = new int[longitud];
        this.indice = 0;
    }

    public bool Insertar(int nota)
    {
        if (indice < longitud)
        {
            notas[indice++] = nota;
            Console.WriteLine("Nota " + nota + " insertada correctamente.");
            return true;
        }
        Console.WriteLine("No se pudo insertar la nota, el arreglo está lleno.");
        return false; // No se pudo insertar, arreglo lleno
    }

    public bool Eliminar(int posicion)
    {
        if (posicion >= 0 && posicion < indice)
        {
            Console.WriteLine("Nota en posición " + posicion + " eliminada.");
            for (int i = posicion; i < indice - 1; i++)
            {
                notas[i] = notas[i + 1];
            }
            indice--;
            return true;
        }
        Console.WriteLine("No se pudo eliminar, posición inválida.");
        return false; // No se pudo eliminar, posición inválida
    }

    public bool Modificar(int posicion, int nuevaNota)
    {
        if (posicion >= 0 && posicion < indice)
        {
            Console.WriteLine("Nota en posición " + posicion + " modificada a " + nuevaNota + ".");
            notas[posicion] = nuevaNota;
            return true;
        }
        Console.WriteLine("No se pudo modificar, posición inválida.");
        return false; // No se pudo modificar, posición inválida
    }

    public int Buscar(int nota)
    {
        for (int i = 0; i < indice; i++)
        {
            if (notas[i] == nota)
            {
                Console.WriteLine("Nota " + nota + " encontrada en posición: " + i);
                return i; // Retorna la posición de la nota
            }
        }
        Console.WriteLine("Nota " + nota + " no encontrada.");
        return -1; // Nota no encontrada
    }

    public void Imprimir()
    {
        Console.WriteLine("Notas almacenadas:");
        for (int i = 0; i < indice; i++)
        {
            Console.WriteLine("Posición " + i + ": " + notas[i]);
        }
    }

    public static void Main(string[] args)
    {
        ManejoNota mn = new ManejoNota(5);
        mn.Insertar(80);
        mn.Insertar(90);
        mn.Insertar(70);
        mn.Insertar(66);
        mn.Insertar(55);
        mn.Insertar(40);
        mn.Imprimir();

        mn.Modificar(1, 95);
        mn.Imprimir();

        mn.Eliminar(0);
        mn.Imprimir();

        int pos = mn.Buscar(70);
       
    }
}
